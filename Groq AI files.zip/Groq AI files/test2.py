import pandas as pd

# Step 1: Ingest Data
customers_df = pd.read_csv("E:\Groq AI files\customers.csv")
orders_df = pd.read_csv("E:\Groq AI files\orders.csv")

# Step 2: Transform - Aggregate total order amount per customer
order_totals = orders_df.groupby("customer_id")["amount"].sum().reset_index()

# Step 3: Integrate - Join customer info with order totals
combined_df = pd.merge(customers_df, order_totals, on="customer_id")

# Step 4: Output - Save integrated data
combined_df.to_csv("customer_order_report.csv", index=False)

# Optional: Display the result
print(combined_df)