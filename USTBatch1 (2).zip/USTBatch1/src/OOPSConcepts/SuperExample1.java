package OOPSConcepts;

class C3
{
	String colour="blue";
}

class C4 extends C3
{
	String colour="red";
	
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
}


public class SuperExample1 {

	public static void main(String[] args) {
		
		C4 obj=new C4();
		obj.display();
		

	}

}
