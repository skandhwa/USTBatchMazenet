package MyPractice1;

class B
{
	
	int x=10;////instance variable
	void display()
	{
		int y=x+10;
		System.out.println(y);
	}
	
	void sum()
	{
		//int z=y+x;
	}
	
	
	
}


public class MyVariableEx {

	public static void main(String[] args) {
		
		B obj=new B();
		obj.display();
		
		

	}

}
