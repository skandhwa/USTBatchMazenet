//package MyPractice1;
//
//public class MySecondPractice {
//	
//	public static void display()
//	{
//		System.out.println("Hello");
//	}
//	
//	
//class Test extends 	MySecondPractice
//{
//	public static void test()
//	{
//		System.out.println("Hi");
//	}
//}
//	
//	
//
//	public static void main(String[] args) {
//		
//		Test obj=new Test();
//		
//		
//
//	}
//
//}
