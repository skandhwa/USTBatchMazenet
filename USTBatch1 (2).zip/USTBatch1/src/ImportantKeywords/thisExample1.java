package ImportantKeywords;

class C15
{
	int id;
	String name;
	float salary;
	
	C15(int id,String name,float salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+salary);
	}
	
}



public class thisExample1 {

	public static void main(String[] args) {
		
		C15 obj=new C15(1234,"Saurabh",80000f);
		obj.display();
		
		
		

	}

}
