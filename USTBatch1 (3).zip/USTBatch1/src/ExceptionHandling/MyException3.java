package ExceptionHandling;

public class MyException3 {

	public static void main(String[] args) {
		
		
		String str=null;
		System.out.println(str.length());///Null pointer Exception
		
		
		
		int x=10;
		int b=20;
		int c=x+b;
		System.out.println(c);

	}

}
