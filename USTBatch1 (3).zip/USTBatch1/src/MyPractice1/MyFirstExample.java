package MyPractice1;

public class MyFirstExample {
	
//	public static void main()
//	{
//		System.out.println("Hi");
//	}
//	
	

	public static void main(String[] a) {
		
		System.out.println("Hello");
		
		
		

	}

}
