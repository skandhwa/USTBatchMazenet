package MyPractice1;

public class UnaryOperatorsEx {

	public static void main(String[] args) {
		
		int a=10;
		
		int b=15;
		
		int c=5;
		
		int res= a++ + ++b + ++a + c++ + ++c; 
		
		// 10 + 16 + 12 + 5 + 7
		
		//a=12, b=16 ,c=6
		
		System.out.println(res);
		
		
		
		
		
		
		

	}

}
