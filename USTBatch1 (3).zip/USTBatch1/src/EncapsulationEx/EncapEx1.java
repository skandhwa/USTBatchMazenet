package EncapsulationEx;

class C16
{
	private String name="Saurabh";
	private int id;
	
	
	public String getName() {
		return name;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	
	
	
	
}




