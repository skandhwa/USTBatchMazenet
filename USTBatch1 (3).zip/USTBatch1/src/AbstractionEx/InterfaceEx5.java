package AbstractionEx;

interface I11
{
	default void test()
	{
		System.out.println("I am test method");
	}
}

class C12 implements I11
{
	
}



public class InterfaceEx5 {

	public static void main(String[] args) {
		
		C12 obj=new C12();
		obj.test();
		

	}

}
