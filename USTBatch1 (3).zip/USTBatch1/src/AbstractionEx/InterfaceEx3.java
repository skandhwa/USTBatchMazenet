package AbstractionEx;

interface I7
{
	void display();
}

interface I8 extends I7
{
	void test();
}

class C10 implements I8
{
	public void display()
	{
		System.out.println("I am display method");
	}
	
	public void test()
	{
		System.out.println("I am test method");
	}
	
}





public class InterfaceEx3 {

	public static void main(String[] args) {
		
		C10 obj=new C10();
		obj.display();
		obj.test();

	}

}
