package StringExamples;

public class StringMethods5 {

	public static void main(String[] args) {
		
		
//		String str="Republic India";
//		
//	String str1=	str.substring(7);
//	
//	System.out.println(str1);
	
	
		String str1="REPUBLICAN";
		
		String str2=str1.substring(4,8);
		
		System.out.println(str2);
		
		
		
				
				
	
	
		

	}

}
