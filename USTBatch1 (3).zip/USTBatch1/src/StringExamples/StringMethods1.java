package StringExamples;

public class StringMethods1 {

	public static void main(String[] args) {
		
		String str="indian";
		
		char ch=str.charAt(4);
		System.out.println(ch);
		
		int x=str.length();
		System.out.println("Total length of String is  "+x);
		
		int y=str.indexOf('i',2);
		System.out.println("Index of i in string is  "+y);
		
		
		String str2="saurabh";
		int z=str2.indexOf('a',2);
		System.out.println("Index of a is  "+z);
		
		
		
		
		
		
		
		
		
		

	}

}
