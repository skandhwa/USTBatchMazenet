package StringExamples;

public class StringDeclarationandTraversal {

	public static void main(String[] args) {
		
		String str="Indian";
		///By using String literal
		
		
	String	str3=str.concat("citizen");
		
		System.out.println(str3);
		
		
//		String str2="Indian";
//		
//		String str1=new String("Saurabh");///By using new keyword
//		
		
	
		
		
		
		

	}

}
