package ImportantKeywords;

//class Car
//{
//	final int speed(int x,int y)
//	{
//		return x+y;
//	}
//}
//
//class Byk extends Car
//{
//	int speed(int x,int y)
//	{
//		return x+y;
//	}
//}
//
//class Bus extends Car
//{
//	int speed(int x,int y)
//	{
//		return x+y;
//	}
//}
//


public class finalforMethod {

	public static void main(String[] args) {
		
//		Byk obj=new Byk();
//	System.out.println(obj.speed(30, 20));	
		

	}

}
