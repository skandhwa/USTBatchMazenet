package ImportantKeywords;

class D2
{
	int id;
	String name;
	float salary;
	static String companyName="CTS";
	
	D2(int id,String name,float salary )
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
		
	}
	static void change()
	{
		companyName="Accenture";
	}
	
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+salary+"  "+companyName);
	}
	
	
	
}



public class StaticVariableEx {

	public static void main(String[] args) {
		
		D2 obj=new D2(1234,"Tom",80000f);
		D2 obj1=new D2(7865,"Harry",90000f);
		D2 obj2=new D2(6532,"Joseph",50000f);
		D2.change();
		obj.display();
		obj1.display();
		obj2.display();

	}

}
