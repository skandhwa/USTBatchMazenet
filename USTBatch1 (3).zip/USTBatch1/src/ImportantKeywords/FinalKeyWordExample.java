package ImportantKeywords;

class D5
{
	final static  int speed=50;
	static void run()
	{
		
		System.out.println(speed);
	}
	
}




public class FinalKeyWordExample {

	public static void main(String[] args) {
		
		D5 obj=new D5();
		obj.run();
		
		

	}

}
