package ImportantKeywords;

public class PlayAroundStatic {
	
	public static void main(String s)
	{
		
		System.out.println(s);
	}
	
	
	

	public static void main(String[] args) 
	{
		PlayAroundStatic.main("Saurabh");

	}

}
