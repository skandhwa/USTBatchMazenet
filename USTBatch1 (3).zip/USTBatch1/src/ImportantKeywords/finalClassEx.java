package ImportantKeywords;

final class D10
{
	void display()
	{
		System.out.println("Hello");
	}
}


class D11 extends D10
{
	void test()
	{
		System.out.println("Hi");
	}
}


public class finalClassEx {

	public static void main(String[] args) {
		
		D11 obj=new D11();
		obj.test();
		obj.display();
		

	}

}
