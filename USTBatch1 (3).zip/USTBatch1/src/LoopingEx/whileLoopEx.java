package LoopingEx;

public class whileLoopEx {

	public static void main(String[] args) {
		
		
//		while(i<10)///5<10///6<10
//		{
//			System.out.println(i);//5//6//7//8//9
//			i++;//5++
//		}
		
		int i=11;
		do
		{
			System.out.println(i);
		}
		
		while(i<10);
		{
			i++;
		}
		

	}

}
