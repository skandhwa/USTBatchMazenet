package OOPSConcepts;

class B10
{
	void display()
	{
		System.out.println("Hi");
	}
}

class B11 extends B10
{
	void test()
	{
		System.out.println("Hello");
	}
}

class B12 extends B10
{
	void message()
	{
		System.out.println("Hi");
	}
}



public class InheritanceEx3 {

	public static void main(String[] args) {
		
		
		B12 obj=new B12();
		obj.message();
		obj.display();
		
	}

}
