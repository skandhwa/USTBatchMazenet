package OOPSConcepts;

class B6
{
	void display()
	{
		System.out.println("Hello");
	}
}

class B7 extends B6
{
	void test()
	{
		System.out.println("Hi ");
	}
}

class B8 extends B7
{
	void message()
	{
		System.out.println("How r u ");
	}
}

class B9 extends B8
{
	void message1()
	{
		System.out.println("How r u saurabh");
	}
}


public class InheritanceEx2 {

	public static void main(String[] args) {
		
		B9 obj=new B9();
		obj.display();
		obj.test();
		obj.message();
		obj.message1();
		

	}

}
