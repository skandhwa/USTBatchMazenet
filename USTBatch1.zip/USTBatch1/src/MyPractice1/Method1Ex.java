package MyPractice1;

class A4
{
	
	void display()
	{
		System.out.println("Hi");///Method with no parameter , no return type
	}
	
	int sum()
	{
		int a=10;
		int b=20;
		int c=a+b;
		return c;///Method with no parameter but have return type
	}
	
	int multiply(int a,int b,int c)
	{
		int res=a*b*c;
		return res;///Method with return type and parameters
	}
	
	void div(int x,int y)
	{
		int z=x/y;
		System.out.println(z);
	}
	
}



public class Method1Ex {

	public static void main(String[] args) {
		
		A4 obj=new A4();
		obj.display();
		
	System.out.println(obj.sum());	
	
	System.out.println	(obj.multiply(12, 15,16));
	
	obj.div(20,2);
	
		
		
		

	}

}
