package MyPractice1;

public class UnaryEx2 {

	public static void main(String[] args) {
		
		int x=5;
		
		int y=10;
		
		int z= 15;
		
		int res=  y++  - --z + --y + ++x - ++z + --x  ; 
		
		/// 10 - 14 + 10  + 6 - 15 + 5
		
		//// y=10 , z=15 ,x=6 
		
		System.out.println(res);
		

	}

}
