package OOPSConcepts;

class C6
{
	void test()
	{
		System.out.println("Hello");
	}
}

class C7 extends C6
{
	void test()
	{
		System.out.println("Hi");
	}
	
	void display()
	{
		System.out.println("I am Saurabh");
	}
	
	void message()
	{
		test();
		display();
		super.test();
		
	}
	
}


public class SuperEx2 {

	public static void main(String[] args) {
		
		C7 obj=new C7();
		obj.message();
		

	}

}
