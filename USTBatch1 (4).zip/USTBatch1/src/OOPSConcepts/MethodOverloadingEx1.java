package OOPSConcepts;

class C12
{
	static int sum(int a,int b)
	{
		return a+b;
	}
	
	static float sum(float c,int d)
	{
		return c+d;
	}
	
	
}


public class MethodOverloadingEx1 {

	public static void main(String[] args) {
		
		C12 obj=new C12();
	System.out.println(obj.sum(23.55f, 45));	
	System.out.println	(obj.sum(10, 20));
		

	}

}
