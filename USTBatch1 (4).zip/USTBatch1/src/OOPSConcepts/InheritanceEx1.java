package OOPSConcepts;

class B1
{
	int sum(int a,int b)
	{
		return a+b;
	}
}

class C1 extends B1
{
	int diff(int c,int d)
	{
		return c-d;
	}
}

public class InheritanceEx1 {

	public static void main(String[] args) {
		
		C1 obj=new C1();
	System.out.println(obj.sum(23, 56));	
		
	System.out.println(obj.diff(45,12));
		
		
		

	}

}
