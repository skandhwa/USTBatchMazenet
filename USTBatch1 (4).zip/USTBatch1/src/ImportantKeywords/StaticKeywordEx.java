package ImportantKeywords;

class D1
{
	
	static void test()
	{
		System.out.println("hello");
	}
}



public class StaticKeywordEx {

	public static void main(String[] args) {
		
		
		D1.test();
		

	}

}
