package ArrayConcepts;

public class ArrayDec {

	public static void main(String[] args) {
		
		int a[]= {23,56,79,85,67};
		
		//int []b=new int[] {68,98,21,46,78};
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
