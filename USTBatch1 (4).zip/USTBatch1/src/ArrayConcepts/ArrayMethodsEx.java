package ArrayConcepts;

import java.util.Arrays;

public class ArrayMethodsEx {

	public static void main(String[] args) {
		
		int []a= {12,45,394,332,878};
		int []b= {12,45,194,932,978};
		
	boolean flag=	Arrays.equals(a,b);
	System.out.println("Are the two arrays equal "+flag);
		
	
	int x=Arrays.compare(b,a);
	
	System.out.println("Comparing two arrays  "+x);
	
		
	    String str= Arrays.toString(a);
	    System.out.println(str);
	    
	    int y=a.length;
	 System.out.println("Copied array is   "+Arrays.copyOf(a, y).toString());   ;
		
	    
	    
	    
		
		Arrays.sort(a);
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
		

	}

}
