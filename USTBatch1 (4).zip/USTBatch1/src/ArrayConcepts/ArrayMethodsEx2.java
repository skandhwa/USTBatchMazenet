package ArrayConcepts;

import java.util.Arrays;

public class ArrayMethodsEx2 {

	public static void main(String[] args) {


		
		int []a= {12,45,394,332,878};
		int x=a.length;
		
		int []b=Arrays.copyOf(a, 3);
		
		for(int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
		

	}

}
