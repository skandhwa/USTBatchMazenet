package CollectionsInterface;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx2 {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add(5);
		li.add("saurabh");
		li.add(false);
		li.add(80000f);
		li.add(8905L);
		
		
		

	}

}
