package CollectionsInterface;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetEx1 {

	public static void main(String[] args) {
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		s1.add(89);
		s1.add(104);
		s1.add(45);
		s1.add(99);
		s1.add(89);
		
		for(Integer x:s1)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
