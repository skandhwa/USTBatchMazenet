package CollectionsInterface;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetEx {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		
		s1.add(90);
		s1.add(18);
		s1.add(106);
		s1.add(190);
		
//		for(Integer x:s1)
//		{
//			System.out.println(x);
//		}
		
		System.out.println("Elements of set in descending order is ");
		
		Iterator itr=s1.descendingIterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		
		

	}

}
