package CollectionsInterface;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(56);
		stk.push(90);
		stk.push(104);
		
		for(Integer x:stk)
		{
			System.out.println(x);
		}
		
		stk.pop();
		
		System.out.println("After deleting elements are");
		
		for(Integer x:stk)
		{
			System.out.println(x);
		}
		

	}

}
