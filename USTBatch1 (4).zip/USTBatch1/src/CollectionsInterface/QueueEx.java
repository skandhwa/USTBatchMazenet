package CollectionsInterface;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx {

	public static void main(String[] args) {
		
		Queue<Integer> q1=new PriorityQueue<Integer>();
		q1.add(23);
		q1.add(45);
		q1.add(96);
		q1.add(180);
		
		for(Integer x:q1)
		{
			System.out.println(x);
		}
		
		System.out.println("after removing element from queue");
		System.out.println();
		q1.remove();
		
		
		
		for(Integer x:q1)
		{
			System.out.println(x);
		}
		
		

	}

}
