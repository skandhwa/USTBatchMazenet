package CollectionsInterface;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx4 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("mango");
		li.add("orange");
		li.add("kiwi");
		li.add("apple");
		
		
	boolean flag=	li.contains("mango");
	System.out.println("Does the list contains Mango  "+flag);
	
	
	li.set(2,"watermelon");
	
	for(String x:li)
	{
		System.out.println(x);
	}
	
	
	li.remove(3);
	System.out.println();
	System.out.println("Removing element from index 3");
	
	for(String x:li)
	{
		System.out.println(x);
	}
	
	
	li.clear();
	System.out.println();
System.out.println("Removing all Elements from list");
	
	for(String x:li)
	{
		System.out.println(x);
	}
		

	}

}
