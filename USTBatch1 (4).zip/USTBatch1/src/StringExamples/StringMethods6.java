package StringExamples;

public class StringMethods6 {

	public static void main(String[] args) {
		
		String str="top tick tack top toe";
		
		String str1=str.replaceAll("top","shop");
		System.out.println(str1);
		
		
		String str2="pick pack";
		
		String str3=str2.replace('p','t');
		
		System.out.println();
		
		
		
		
		
		
		
		
		
		
		

	}

}
