package StringExamples;

public class StringMethods7 {

	public static void main(String[] args) {
		
		
		String str="    sa   urabh   ";
		String str1=str.trim();
		
		System.out.println(str1);
		
		
		

	}

}
