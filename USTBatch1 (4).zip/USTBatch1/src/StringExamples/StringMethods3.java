package StringExamples;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str="tic tac toe zig zag go";
		
		String []a1= str.split(" ");
		
		System.out.println(a1[4]);
		
//		for(int i=0;i<a1.length;i++)
//		{
//			System.out.println(a1[i]);
//		}
//		
		
		String str1="timestamp#trip#goa#sunburn";
	String []a=	str1.split("#");
	
	System.out.println(a[2]);
		
		

	}

}
