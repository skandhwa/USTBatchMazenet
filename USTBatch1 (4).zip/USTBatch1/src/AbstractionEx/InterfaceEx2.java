package AbstractionEx;

interface I5
{
	void display();
}

interface I6
{
	void test();
}

class C8 implements I5,I6
{
	public void display()
	{
		System.out.println("Hello");
	}
	
	public void test()
	{
		System.out.println("Hi");
	}
}




public class InterfaceEx2 {

	public static void main(String[] args) {
		
		C8 obj=new C8();
		obj.display();
		obj.test();
		

	}

}
