package AbstractionEx;

interface I9
{
	static void display()
	{
		System.out.println("Hello");
	}
}



public class InterfaceEx4 {

	public static void main(String[] args) {
		
		
		I9.display();
		
		
		

	}

}
