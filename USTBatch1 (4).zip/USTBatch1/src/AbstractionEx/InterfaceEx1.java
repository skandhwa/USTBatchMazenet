package AbstractionEx;

interface I1
{
	 void display();
	void test();
	void message();
	
	 int x=20;
}

class D20 implements I1
{
	public void display()
	{
		System.out.println("Hi");
	}
	
	public void test()
	{
		System.out.println("Hello");
	}
	public void message()
	{
		System.out.println("Welcome");
	}
}

class D21
{
	public void message()
	{
		System.out.println("Welcome");
	}
}





public class InterfaceEx1 {

	public static void main(String[] args) {
		
		I1 ref=new D20();
		ref.test();
		ref.message();
		ref.display();
		

	}

}
