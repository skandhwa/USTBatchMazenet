package AbstractionEx;

abstract class D12
{
	abstract void display();
	
	void test()
	{
		System.out.println("Hello");
	}
	
	void message()
	{
		System.out.println("This is Saurabh");
	}
	
	void demo()
	{
		System.out.println("Hello I am concrete");
	}
	
}

class D13 extends D12
{
	void display()
	{
		System.out.println("Hi I was an abstract method");
	}
}

public class AbstractClassEx1 {

	public static void main(String[] args) {
		
		D12 ref=new D13();
		ref.display();
		ref.test();
		ref.message();
		

	}

}
