package EncapsulationEx;

public class EncapEx2 {

	public static void main(String[] args) {
		
		C16 obj=new C16();
		
		obj.setId(89765);
		
		System.out.println("ID is  "+obj.getId());
		System.out.println("Name is  "+obj.getName());
		

	}

}
