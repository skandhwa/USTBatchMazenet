package ExceptionHandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

class E3
{
	public static void validateFileAccess(int id) throws IOException
	{
		if(id==123456)
		{
			FileReader f=new FileReader("D:\\Git Commands New.txt");
			BufferedReader br=new BufferedReader(f);
		boolean flag    =  br.ready()   ;   
		
		if(flag==true)
		{
		
			System.out.println("File exist please carry on");
		}
		else
		{
			System.out.println("File does not exist");
		}
		}
		
		else
		{
			throw new FileNotFoundException("File Not Present");
		}
		
	}
}




public class ThrowCheckedException {

	public static void main(String[] args) throws FileNotFoundException {
		
		E3.validateFileAccess(123456);
		
		
		
		

	}

}
