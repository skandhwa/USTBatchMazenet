package Java8;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class WithStreamAPI {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("India");
		li.add("Nepal");
		li.add("USA");
		li.add("UK");
		li.add("Netherland");
		
		Stream<String> st=li.stream();
		
	List<String> li2=	st.filter((p -> p.startsWith("N"))).collect(Collectors.toList());
		
	System.out.println(li2);
		
		

	}

}
