package Java8;

@FunctionalInterface
interface I18
{
	public abstract void hello();
	
}


public class FunctionalInterface2 {

	public static void main(String[] args) {
		
		I18 obj = ()->
	
			System.out.println("How are you ");
			
		
		obj.hello();
		
		

	}

}
