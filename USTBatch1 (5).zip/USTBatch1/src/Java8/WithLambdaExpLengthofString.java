package Java8;

@FunctionalInterface
interface I15
{
	public int getLength(String str);
	
}


public class WithLambdaExpLengthofString {

	public static void main(String[] args) {
		
		I15 obj= (str) -> str.length();
		
		int result=obj.getLength("Republic");
		
		System.out.println(result);
		
		

	}

}
