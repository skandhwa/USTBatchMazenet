package Java8;

@FunctionalInterface
interface I20
{
	public void test(int a,int b);
	
	static  void message() {
System.out.println("Hello");
}
}
public class IdentifyFunctionalInterface {

	public static void main(String[] args) {
		
		I20 ref= (int a,int b)-> 
		{
			int c=a+b;
			int d=a-b;
			System.out.println(c);
			System.out.println(d);
		}
		;
		
		ref.test(20, 30);
		
		I20.message();
		
		

	}

}
