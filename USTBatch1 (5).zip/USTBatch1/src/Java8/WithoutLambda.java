package Java8;

interface I8
{
	public int sum(int a,int b);
}

class C11 implements I8
{
	public int sum(int a,int b)
	{
		return a+b;
	}
}


public class WithoutLambda {

	public static void main(String[] args) {
		
		I8 ref=new C11();
	System.out.println(ref.sum(45, 89));	
		

	}

}
