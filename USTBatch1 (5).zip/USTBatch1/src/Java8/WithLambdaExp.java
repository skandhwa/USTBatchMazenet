package Java8;

@FunctionalInterface
interface I13
{
	public int sum(int a,int b);
}


public class WithLambdaExp {

	public static void main(String[] args) {
		
		
		 I13 obj = (a, b) -> a + b;

	       
	        int result = obj.sum(10, 20);
	        System.out.println("Sum: " + result);

	}

}
