package Java8;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class MethodReference {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(40);
		li.add(5);
		li.add(70);
		li.add(10);
		li.add(9);
		
		
		  li.stream()
          .filter(x -> x > 5)
          .sorted()
          .forEach(System.out::println);

		  
		  LocalTime time=LocalTime.now();
		  System.out.println(time);
		  
		  LocalDate date=LocalDate.now();
		  System.out.println(date);
		  
	}

}
