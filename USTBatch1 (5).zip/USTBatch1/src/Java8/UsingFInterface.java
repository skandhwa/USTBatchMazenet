package Java8;

@FunctionalInterface
interface square
{
	int calculate(int x);
}

public class UsingFInterface {

	public static void main(String[] args) {
		
		square s=(int x) ->x*x;
		
		int val=s.calculate(5);
		System.out.println(val);
		
		

	}

}
