package Java8;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class WithouStreamAPI {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(40);
		li.add(5);
		li.add(70);
		li.add(10);
		li.add(9);
		
//		List<Integer> li2=new ArrayList<Integer>();
//		
//		for(Integer x:li)
//		{
//			if(x%2==0)
//			{
//				li2.add(x);
//			}
//		}
//		
//		System.out.println(li2);
		
		
		Stream<Integer> st=li.stream();
		
		List<Integer> li2=st.filter(i ->i%2==0).collect(Collectors.toList());
		System.out.println(li2);
		
		
		

	}

}
