package MyPractice1;

class A3
{
	int id;
	String name;
	float salary;
	boolean isMarried;
	
	A3(int i,String n,float s)
	{
		id=i;
		name=n;
		salary=s;
	}
	
	A3(int i,String n,float s,boolean m)
	{
		id=i;
		name=n;
		salary=s;
		isMarried=m;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+salary+"  "+isMarried);
	}
	
	
}

public class ParameterizedConstructor {

	public static void main(String[] args) {
		
		A3 obj=new A3(1234,"Saurabh",70000f);
		obj.display();
		
		A3 obj1=new A3(5678,"Gaurabh",90000f,true);
		obj1.display();
		
		
		

	}

}
