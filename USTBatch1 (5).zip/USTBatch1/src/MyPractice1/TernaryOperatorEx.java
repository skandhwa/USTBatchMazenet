package MyPractice1;

public class TernaryOperatorEx {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		int c=15;
		
//		int max= (a>b) ?a:b; //// 10>20 
//		
//		System.out.println(max);
		
		int max=(a>b)?(a>c?a:c):(b>c?b:c);
		System.out.println(max);
		
		
		
		

	}

}
