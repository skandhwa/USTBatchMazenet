package MyPractice1;

class A
{
	void display()
	{
		int a=10;
		int b=15;
		int c=a+b;
		System.out.println(c);
	}
}




public class MyThirdExample {

	public static void main(String[] args) {
		
		A obj=new A();
		obj.display();
	
		
		

	}

}
