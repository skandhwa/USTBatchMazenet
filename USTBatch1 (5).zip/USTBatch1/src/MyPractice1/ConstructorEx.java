package MyPractice1;

class A1
{
	
	
	void display()
	{
		System.out.println("Hello");
	}
}



public class ConstructorEx {

	public static void main(String[] args) {
		
		A1 obj=new A1();
		obj.display();
		

	}

}
