package ExceptionHandling;

public class MyException3 {

	public static void main(String[] args) {
		
		try
		{
		String str=null;
		System.out.println(str.length());///Null pointer Exception
		}
		
		catch(NullPointerException e)
		{
			System.out.println("caught with  "+e);
		}
		
		
		int x=10;
		int b=20;
		int c=x+b;
		System.out.println(c);

	}

}
