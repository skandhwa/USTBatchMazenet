package ExceptionHandling;

public class FinallyClause {

	public static void main(String[] args) {
		
		try
		{
		
		int a=20;
		int x=a/0;
		System.out.println(x);
		
		}
		
		
		
		finally
		{
			System.out.println("I will always execute");
		}
		
		
		
		
		
		
		
		

	}

}
