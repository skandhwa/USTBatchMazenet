package ExceptionHandling;

public class MyException2 {

	public static void main(String[] args) {
		
		try
		{
		int a[]=new int[3];
		a[0]=12;
		a[1]=22;
		a[2]=32;
		a[3]=42;
		a[4]=52;
		
		System.out.println(a[4]);///Array Index out of bounds
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		
		

		int x=10;
		int b=20;
		int c=x+b;
		System.out.println(c);
		

	}

}
