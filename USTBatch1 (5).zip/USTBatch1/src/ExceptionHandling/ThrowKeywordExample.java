package ExceptionHandling;

class E1
{
	
	public static void validateAge(int a)
	{
		if(a>18)
		{
			System.out.println("You are elligible to vote");
		}
		else
		{
			throw new ArithmeticException("You are not elligible" );
		}
	}
	
	
	
}

public class ThrowKeywordExample {

	public static void main(String[] args) {
		
	    
		E1.validateAge(13);
		
		
		
		

	}

}
