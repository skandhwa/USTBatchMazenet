package ImportantKeywords;

public class StaticBlockExample {
	
	
	StaticBlockExample()
	{
		System.out.println("Hello I am constructor");
	}
	
	static 
	{
		
		System.out.println("Hi");
	}
	
	static
	{
		System.out.println("Welcome");
	}
	
	
	
	

	public static void main(String[] args) {
		
		StaticBlockExample obj=new StaticBlockExample();
         System.out.println("Hello");
         
		
	}

}
