package ImportantKeywords;

class C17
{
	int id;
	String name;
	float salary;
	String address;
	C17(int id,String name,float salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
	C17(int id,String name,float salary,String address)
	{
		this(id,name,salary);
		this.address=address;
	}
	
	
	
	
}



public class thisExample2 {

	public static void main(String[] args) {
		
		
		

	}

}
