package OOPSConcepts;

class C8
{
	int id;
	String name;
	float salary;
	
	C8(int i,String n,float s)
	{
		id=i;
		name=n;
		salary=s;
	}
}

class C9 extends C8
{
	int id;
	String name;
	float salary;
	String address;
	
	C9(int i,String n,float s,String a)
	{
		super(i,n,s);
		address=a;
	}
	
	void display()
	{
		System.out.println(id+" "+name+" "+salary+"  "+address);
	}
	
	
}






public class SuperExample3 {

	public static void main(String[] args) {
		
		C9 obj=new C9(1234,"Saurabh",80000f,"Hyderabad");
		obj.display();
		

	}

}
