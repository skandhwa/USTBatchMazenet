package OOPSConcepts;

class C2
{
	void display()
	{
		System.out.println("Hello");
	}
	
	void test()
	{
		System.out.println("Hi");
	}
	
	void message()
	{
		display();
		test();
		
	}
	
}



public class CascadedMethods {

	public static void main(String[] args) {
		
		C2 obj=new C2();
		obj.message();
		
		
		
		

	}

}
