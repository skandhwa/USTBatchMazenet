package StringExamples;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="Indian";
		
		char []ch=str.toCharArray();
		
		for(int i=0;i<ch.length;i++)
		{
			System.out.println(ch[i]);
		}
		
		
		
		
		

	}

}
