package StringExamples;

public class StringMethods4 {

	public static void main(String[] args) {
		
		String str="Java";
		
		String str1="java";
		
	boolean flag=	str.equalsIgnoreCase(str1);
	
	System.out.println("Are two Strings identical  "+flag);
		
		
		

	}

}
