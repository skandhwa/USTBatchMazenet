package Programs;

public class SumOfAllElementsArray {

	public static void main(String[] args) {
		
		int []a= {3,6,1,4,5};
		int sum=0;
		
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		
		System.out.println(sum);

	}

}
