package Programs;

public class ReverseOfString {

	public static void main(String[] args) {
		
		String str="madame";
		String str1=str;
		
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)
		{
			revstr=revstr+str.charAt(i);//""+
		}
		
		System.out.println(revstr);
		
		if(str1.equalsIgnoreCase(revstr))
		{
			System.out.println("String is palindrome");
		}
		
		else
		{
			System.out.println("Not Palindrome");
		}
		

	}

}
