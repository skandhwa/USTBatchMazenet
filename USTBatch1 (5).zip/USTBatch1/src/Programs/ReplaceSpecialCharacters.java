package Programs;

public class ReplaceSpecialCharacters {

	public static void main(String[] args) {
		
		String str="@*saurabh^#$";
		
		String str1= str.replaceAll("[^a-zA-Z0-9]","");
		
		System.out.println(str1);
		
		
		

	}

}
