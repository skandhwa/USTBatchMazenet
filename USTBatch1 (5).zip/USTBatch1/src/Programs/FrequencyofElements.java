package Programs;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofElements {

	public static void main(String[] args) {
		
		int []a= {10,70,20,10,20,10};
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		for(int x:a)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));///mp.put(10,1+1)//mp.put(10,2)
			}
			
			else
			{
				mp.put(x,1);//mp.put(20,1)
			}
			
			
			
		}
		
		for(Map.Entry k:mp.entrySet())
		{
			System.out.print(k.getKey()+"  ");
			System.out.println(k.getValue());
		}
		
		
		
		

	}

}
