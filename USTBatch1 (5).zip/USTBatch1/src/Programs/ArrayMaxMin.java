package Programs;

class ArrayEx
{
	public static int MaxMin(int []a,int total)
	{
		for(int i=0;i<a.length;i++)//i=0,0<5//i=1
		{
			for(int j=i+1;j<a.length;j++)//j=1,1<5//j=4,4<5//j=5,5<5
			{
				if(a[i]>a[j])///a[0]>a[1]//a[0]>a[2]//a[0]>a[4]
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		return a[2];
		
		
		
	}
}



public class ArrayMaxMin {

	public static void main(String[] args) {
		
		int []a= {2,5,1,7,4};
		int x=a.length;
		System.out.println("Third smallest  element is  "+ArrayEx.MaxMin(a, x));
		
		
		

	}

}
