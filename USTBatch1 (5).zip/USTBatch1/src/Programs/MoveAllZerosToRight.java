package Programs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MoveAllZerosToRight {

	public static void main(String[] args) {
		
		int []a= {2,0,3,0,1,6,0,8};
		
		List<Integer> li1=new ArrayList<Integer>();
		List<Integer> li2=new ArrayList<Integer>();
		
		for(int x:a)
		{
			if(x!=0)
			{
				li1.add(x);
			}
			
			else
			{
				li2.add(x);
			}
		}
		
		Collections.sort(li1);
		
		Collections.reverse(li1);
		
		li1.addAll(li2);
		
		for(Integer y:li1)
		{
			System.out.print(y+" ");
		}
		
		
		

	}

}
