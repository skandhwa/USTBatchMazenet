package Programs;

import java.util.LinkedHashMap;
import java.util.Map;

public class StringFrequency {

	public static void main(String[] args) {
		
		String str="saurabh";
		
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		
		char []ch=str.toCharArray();
		
		for(Character x:ch)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
			}
			else
			{
				mp.put(x,1);
			}
		}
		
		

		for(Map.Entry k:mp.entrySet())
		{
			System.out.print(k.getKey()+"  ");
			System.out.println(k.getValue());
		}
		
		
		

	}

}
