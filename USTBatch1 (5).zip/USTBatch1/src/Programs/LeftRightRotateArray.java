package Programs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LeftRightRotateArray {

	public static void main(String[] args) {
		
		
		int []a= {2,4,6,1,5};
		
		List<Integer> li=new ArrayList<Integer>();
		
		for(int x:a)
		{
			li.add(x);
		}
		
		Collections.rotate(li, -2);
		
		for(int y:li)
		{
			System.out.print(y+" ");
		}
		

	}

}
