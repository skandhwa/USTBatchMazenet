package CollectionsInterface;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapEx {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new TreeMap<Integer,String>();
		mp.put(12,"apple");
		mp.put(1, "orange");
		mp.put(43,"kiwi");
		mp.put(6,"mango");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
	boolean flag=	mp.containsKey(143);
	System.out.println(flag);
	
	System.out.println();
	System.out.println();
	System.out.println(mp.get(6));
	
	
	
	
		
		

	}

}
