package CollectionsInterface;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx3 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(46);
		li.add(99);
		li.add(104);
		
		List<Integer> li2=new ArrayList<Integer>();
		li2.add(23);
		li2.add(46);
		li2.add(919);
		li2.add(404);
		
		
//		li.addAll(li2);
//		
//		System.out.println(li);
		
//	boolean flag=	li2.containsAll(li);
//	
//	System.out.println(flag);
		
	
		
		li.removeAll(li2);
		
		System.out.println(li);
		
		
		

	}

}
