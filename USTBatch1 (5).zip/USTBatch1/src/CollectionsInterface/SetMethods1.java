package CollectionsInterface;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetMethods1 {

	public static void main(String[] args) {
		
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		s1.add(89);
		s1.add(104);
		s1.add(45);
		s1.add(99);
	
		
		
		Set<Integer> s2=new LinkedHashSet<Integer>();
		s2.add(89);
		s2.add(1104);
		s2.add(415);
		s2.add(919);
		s2.add(189);

//		s1.addAll(s2);
//		
//		for(Integer x:s1)
//		{
//			System.out.println(x);
//		}
		
//		s1.containsAll(s2);
//		System.out.println(s1);
		
		s1.removeAll(s2);
		System.out.println(s1);
		
		
		
	}

}
