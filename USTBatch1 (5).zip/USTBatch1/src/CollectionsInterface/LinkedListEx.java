package CollectionsInterface;

import java.util.LinkedList;

public class LinkedListEx {

	public static void main(String[] args) {
		
		
		LinkedList<Integer> li=new LinkedList<Integer>();
		li.add(23);
		li.add(46);
		li.add(99);
		li.add(104);

	}

}
