package CollectionsInterface;

import java.util.LinkedHashMap;
import java.util.Map;

public class MergTwoMaps {

	public static void main(String[] args) {
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		mp.put(1,35);
		mp.put(2,78);
		mp.put(0,65);
		mp.put(3,87);
		
		
		Map<Integer,Integer> mp2=new LinkedHashMap<Integer,Integer>();
		mp2.put(11,135);
		mp2.put(12,718);
		mp2.put(10,165);
		mp2.put(13,871);
		
		
		mp.putAll(mp2);
		
		System.out.println(mp);
		

	}

}
