package CollectionsInterface;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapExample1 {

	public static void main(String[] args) {
		
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		mp.put(1,35);
		mp.put(2,null);
		mp.put(0,null);
		mp.put(null,87);
		
		
		System.out.println(mp);
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey() +"  ");
			System.out.println(x.getValue());
		}
		
		
		
		
		
		

	}

}
